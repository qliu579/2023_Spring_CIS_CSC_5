/* 
 * File:   main.cpp
 * Author: Quanyu Liu
 * Created on May 1, 2023, 8:56PM
 * Purpose: Implementation of the game of Blackjack
 */

//System Libraries 
#include <iostream>         //Input/output library
#include <fstream>          //File library
#include <iomanip>          //Formatting library
#include <cstdlib>          //Random function library
#include <ctime>            //Time library
#include <cmath>            //Math library
using namespace std;

//User Libraries 

//Global Constants Math/Physics/Chemistry/Conversions ONLY

//Function Prototypes
void pullcrd(const int ,int&,int&,int&,int&,int&,int&,int&,int&,int&,int&,int&);
//Execution Begins HERE

/*
 * 
 */
int main(int argc, char** argv) {
   
    
    //Declare variables
    const int nCards = 52; //Number of cards
    char face,      //Face of cards
         again,     //play again or not 
         suit,      //All the suits in a deck
         hors;      //hit or stand
    int  pltot,     //Player total
         plcd1,     //Player card 1
         plcd2,     //Player card 2
         plcd3,   //Player card 3
         plcd4,   //Player card 4
         plcd5,   //Player card 5   
         dltot,     //Dealer total
         dlcd1,     //Dealer card 1
         dlcd2,     //Dealer card 2
         dlcd3,   //Dealer card 3
         dlcd4,   //Dealer card 4
         dlcd5;   //Dealer card 5  
            
    
    fstream input;
    string fileName;
    string strCard="  ";
    string  card1,
            card2,
            card3,
            card4,
            card5,
            card6,
            card7,
            card8,
            card9,
            card10;
    
    
    //Initialize file parameters
     cout<<"This is a Blackjack game!"<<endl;
            cout<<"Type anything to start"<<endl;
            cin>>again;
            again='Y';
             while(again=='Y'||again=='y'){
    
    fileName="cards.dat";
    input.open(fileName.c_str(),ios::in);
    
    
           
      
    
    //Map Input to Outputs - Process
           
           
            
            
            
    //Set random number seed
           
    //pull cards
         pullcrd(nCards,plcd1,plcd2,plcd3,plcd4,plcd5,dlcd1,dlcd2,dlcd3,dlcd4,dlcd5,dltot);
       
            
           
            //Pull cards from file
                string cardIn;
                for(int card=1;card<=nCards;card++){
                    input>>cardIn;
                    if(plcd1==card)card1=cardIn;
                    if(plcd2==card)card2=cardIn;
                    if(dlcd1==card)card3=cardIn;
                    if(dlcd2==card)card4=cardIn;
                    if(plcd3==card)card5=cardIn;
                    if(dlcd3==card)card6=cardIn;
                    if(plcd4==card)card7=cardIn;
                    if(dlcd4==card)card8=cardIn;
                    if(plcd5==card)card9=cardIn;
                    if(dlcd5==card)card10=cardIn;
                }
                
                            if(plcd1%13>10||plcd1%13==0){                           //Calculate player card 1
                                plcd1=10;
                            }
                            else if(plcd1%13==1){
                                plcd1=11;
                            }
                            else plcd1=plcd1%13;

                            if(plcd2%13>10||plcd2%13==0){                          //Calculate player card 2
                                plcd2=10;
                            }
                            else if(plcd1%13==1){
                                plcd2=11;
                            }else plcd2=plcd2%13;

                            if(plcd3%13>10||plcd3%13==0){                         //Calculate player card 3
                                plcd3=10;
                            }
                            else if(plcd3%13==1){
                                plcd3=11;
                            }else plcd3=plcd3%13;
                            
                            if(plcd4%13>10||plcd4%13==0){                          //Calculate player card 4
                                plcd4=10;
                            }else if(plcd4%13==1){
                                plcd4=11;
                            }else plcd4=plcd4%13;
                            
                            if(plcd5%13>10||plcd5%13==0){                           //Calculate player card 5
                                plcd5=10;
                            }else if(plcd5%13==1){
                                plcd5=11;
                            }else plcd5=plcd5%13;
                            
                            if(dlcd1%13>10||dlcd1%13==0){                           //Calculate dealer card 1
                                dlcd1=10;
                            }
                            else if(dlcd1%13==1){
                                dlcd1=11;
                            }
                            else dlcd1=dlcd1%13;

                            if(dlcd2%13>10||dlcd2%13==0){                          //Calculate dealer card 2
                                dlcd2=10;
                            }
                            else if(dlcd1%13==1){
                                dlcd2=11;
                            }else dlcd2=dlcd2%13;

                            if(dlcd3%13>10||dlcd3%13==0){                         //Calculate dealer card 3
                                dlcd3=10;
                            }
                            else if(dlcd3%13==1){
                                dlcd3=11;
                            }else dlcd3=dlcd3%13;
                            
                            if(dlcd4%13>10||dlcd4%13==0){                          //Calculate dealer card 4
                                dlcd4=10;
                            }else if(dlcd4%13==1){
                                dlcd4=11;
                            }else dlcd4=dlcd4%13;
                            
                            if(dlcd5%13>10||dlcd5%13==0){                           //Calculate dealer card 5
                                dlcd5=10;
                            }else if(dlcd5%13==1){
                                dlcd5=11;
                            }else dlcd5=dlcd5%13;
                            
                
                
            cout<<"Your cards:"<<endl;
            cout<<setw(3)<<card1<<setw(3)<<card2<<endl<<endl;
            cout<<"Dealer's first card:"<<endl;
            cout<<setw(3)<<card3<<endl<<endl;
            
            if(card1=="AS"&&card2=="TS"||card1=="AS"&&card2=="TD"||card1=="AS"&&card2=="TC"||card1=="AS"&&card2=="TH"||              //When blackjack
                    card1=="TS"&&card2=="AD"||card1=="TS"&&card2=="AC"||card1=="TS"&&card2=="AH"||card1=="AD"&&card2=="TD"||
                    card1=="AD"&&card2=="TC"||card1=="AD"&&card2=="TH"||card1=="TD"&&card2=="AC"||card1=="TD"&&card2=="AH"||
                    card1=="AC"&&card2=="TC"||card1=="AC"&&card2=="TH"||card1=="TC"&&card2=="AH"||card1=="AH"&&card2=="TH"){
                cout<<"Blackjack!"<<endl<<"You Won !"<<endl;
            }else {
                cout<<"Hit or Stand ?(h/s)"<<endl;                                                             //First time hit or stand
                cin>>hors; 
                if(hors!='h'&&hors!='H'&&hors!='s'&&hors!='S')
                    cout<<"Invalid Input!";
                            else if(hors=='s'||hors=='S'){                                                                      //First time stand
                    cout<<"dealer's second card:"<<endl;
                    cout<<setw(3)<<card4<<endl<<endl;
                   
                    
                    pltot=plcd1+plcd2;
                    
                                if(pltot>21&&plcd2==11){                                                //Determine when 'A' card is equal to 11 or 1-----player
                                    plcd2=1;
                                    pltot=plcd1+plcd2;
                                    if(pltot>21&&plcd1==11){
                                        plcd1=1;
                                        pltot=plcd1+plcd2;
                                    }
                                }
                    
                    dltot=dlcd1+dlcd2;
                                if(dltot>21&&dlcd2==11){                                                //Determine when 'A' card is equal to 11 or 1-----dealer
                                    dlcd2=1;
                                    dltot=dlcd1+dlcd2;
                                    if(dltot>21&&dlcd1==11){
                                        dlcd1=1;
                                        dltot=dlcd1+dlcd2;
                                    }
                                }
                    
                    
                    cout<<"Your Total is : "<<pltot<<endl;
                    cout<<"The dealer's total is "<<dltot<<endl;
                    if(pltot>dltot){
                        cout<<"You Won !"<<endl<<endl;
                    }
                        else if(pltot==dltot){
                            cout<<"Tie !"<<endl<<endl;
                        }else if(pltot<dltot){
                            cout<<"You Lost !"<<endl<<endl;
                        }
                    
                        
                    }else if(hors=='H'||hors=='h'){                                                         //First time hit
                        cout<<"Your third card :"<<endl;
                        cout<<setw(3)<<card5<<endl<<endl;
                        cout<<"All the cards in your hand : "<<endl;
                        cout<<setw(3)<<card1<<setw(3)<<card2<<setw(3)<<card5<<endl<<endl;
                        cout<<"Hit or Stand ? (h/s)"<<endl;
                        cin>>hors;                                                                          //Second time hit or stand
                        if(hors=='S'||hors=='s'){                                                           //Second time stand
                            
                        
                           

                            pltot=plcd1+plcd2+plcd3;                                      //Determine when card 'A' is equal to 11 or 1 -----player
                            if(pltot>21&&plcd3==11){
                                plcd3=1;
                                pltot=plcd1+plcd2+plcd3;
                                if(pltot>21&&plcd2==11){
                                    plcd2=1;
                                    pltot=plcd1+plcd2+plcd3;
                                    if(pltot>21&&plcd1==11){
                                        plcd1=1;
                                        pltot=plcd1+plcd2+plcd3;
                                    }
                                }
                            }
                               


                            dltot=dlcd1+dlcd2;
                            if(dltot<17){
                                
                                cout<<"All the cards in dealer's hand :"<<endl;
                                cout<<setw(3)<<card3<<setw(3)<<card4<<setw(3)<<card6<<endl<<endl;
                                        
                                
                                dltot=dlcd1+dlcd2+dlcd3;
                                if(dltot>21&&dlcd3==11){
                                dlcd3=1;
                                dltot=dlcd1+dlcd2+dlcd3;
                                if(dltot>21&&dlcd2==11){
                                    dlcd2=1;
                                    dltot=dlcd1+dlcd2+dlcd3;
                                    if(dltot>21&&dlcd1==11){
                                        dlcd1=1;
                                        dltot=dlcd1+dlcd2+dlcd3;
                                    }
                                }
                            }

                            }else{ 
                            cout<<"All the cards in dealer's hand :"<<endl;
                            cout<<setw(3)<<card3<<setw(3)<<card4<<endl<<endl;}
                    
                            cout<<"Your total = "<<card1<<" + "<<card2<<" + "<<card3<<" = "<<pltot<<endl<<endl;
                            cout<<"The dealer's total = "<<dltot<<endl<<endl;
                            if(pltot>21){
                                cout<<"Busted ! "<<endl;
                                cout<<"You lost !"<<endl<<endl;
                            }else if(dltot>21){
                                cout<<"Dealer busted!"<<endl;
                                cout<<"You won !"<<endl<<endl;
                            }
                            else if(pltot<dltot){
                                cout<<"You lost ! "<<endl<<endl;
                            }else if(pltot==dltot){
                                cout<<"Tie !"<<endl<<endl;
                            }else if(pltot>dltot){
                                cout<<"You won ! "<<endl<<endl;
                            }
                    
                    }else if(hors=='H'||hors=='h'){                                                           //Second time hit
                        cout<<"Your fourth card : "<<endl;
                        cout<<setw(3)<<card7<<endl<<endl;
                        cout<<"All the cards in your hand : "<<endl;
                        cout<<setw(3)<<card1<<setw(3)<<card2<<setw(3)<<card5<<setw(3)<<card7<<endl<<endl;
                        cout<<"Hit or Stand ? (h/s)"<<endl;
                        cin>>hors;                                                                            //Third time hit or stand
                        if(hors=='S'||hors=='s'){                                                             //Third time stand
                         
                            pltot=plcd1+plcd2+plcd3+plcd4;                                      //Determine when card 'A' is equal to 11 or 1
                            if(pltot>21&&plcd4==11){
                                plcd4=1;
                                pltot=plcd1+plcd2+plcd3+plcd4;
                                if(pltot>21&&plcd3==11){
                                    plcd3=1;
                                    pltot=plcd1+plcd2+plcd3+plcd4;
                                    if(pltot>21&&plcd2==11){
                                        plcd2=1;
                                        pltot=plcd1+plcd2+plcd3+plcd4;
                                        if(pltot>21&&plcd1==11){
                                            plcd1=1;
                                            pltot=plcd1+plcd2+plcd3+plcd4;
                                        }
                                    }
                            }
                           }     
                        
                        dltot=dlcd1+dlcd2;
                        if(dltot>=17){                  
                          
                           dltot=dlcd1+dlcd2;
                                if(dltot>21&&dlcd2==11){                                                //Determine when 'A' card is equal to 11 or 1-----dealer
                                    dlcd2=1;
                                    dltot=dlcd1+dlcd2;
                                    if(dltot>21&&dlcd1==11){
                                        dlcd1=1;
                                        dltot=dlcd1+dlcd2;
                                    }
                                }
                        }
                                else if(dltot<17){                                                   //if at this time sum of dealer's card < 17, dealer pulls another card
                            dltot=dlcd1+dlcd2+dlcd3;
                            if(dltot<17){
                                dltot=dlcd1+dlcd2+dlcd3+dlcd4;
                              
                                
                                if(dltot>21&&dlcd4==11){                                              //Determine when 'A' card is equal to 11 or 1-----dealer
                                dlcd4=1;
                                dltot=dlcd1+dlcd2+dlcd3+dlcd4;
                                 if(dltot>21&&dlcd3==11){
                                 dlcd3=1;
                                    dltot=dlcd1+dlcd2+dlcd3+dlcd4;
                                     if(dltot>21&&dlcd2==11){
                                    dlcd2=1;
                                    dltot=dlcd1+dlcd2+dlcd3+dlcd4;
                                    if(dltot>21&&dlcd1==11){
                                        dlcd1=1;
                                        dltot=dlcd1+dlcd2+dlcd3+dlcd4;
                                    }
                                }
                            }
                            }
                            }if(dltot>=17){                                                                //if at this time sum of dealer's card < 17, dealer pulls another card
                                
                                 dltot=dlcd1+dlcd2+dlcd3;
                                if(dltot>21&&dlcd3==11){                                          //Determine when 'A' card is equal to 11 or 1-----dealer
                                dlcd3=1;
                                dltot=dlcd1+dlcd2+dlcd3;
                                if(dltot>21&&dlcd2==11){
                                    dlcd2=1;
                                    dltot=dlcd1+dlcd2+dlcd3;
                                    if(dltot>21&&dlcd1==11){
                                        dlcd1=1;
                                        dltot=dlcd1+dlcd2+dlcd3;
                                    }
                                }
                            }
                            }
                        }
                        
                        
                        if(dltot==dlcd1+dlcd2+dlcd3+dlcd4){
                            cout<<"All the cards in dealer's hand : "<<endl;
                            cout<<setw(3)<<card3<<setw(3)<<card4<<setw(3)<<card6<<setw(3)<<card8<<endl<<endl;
                        }
                        if(dltot==dlcd1+dlcd2+dlcd3){
                            cout<<"All the cards in dealer's hand : "<<endl;
                            cout<<setw(3)<<card3<<setw(3)<<card4<<setw(3)<<card6<<endl<<endl;
                        }
                        if(dltot==dlcd1+dlcd2){
                            cout<<"All the cards in dealer's hand : "<<endl;
                            cout<<setw(3)<<card3<<setw(3)<<card4<<endl<<endl;
                        }
                            cout<<"Your total = "<<pltot<<endl<<endl;
                            cout<<"The dealer's total = "<<dltot<<endl<<endl;
                            if(pltot>21){
                                cout<<"Busted ! "<<endl;
                                cout<<"You lost !"<<endl<<endl;
                            }else if(dltot>21){
                                cout<<"Dealer busted!"<<endl;
                                cout<<"You won !"<<endl<<endl;
                            }
                            else if(pltot<dltot){
                                cout<<"You lost ! "<<endl<<endl;
                            }else if(pltot==dltot){
                                cout<<"Tie !"<<endl<<endl;
                            }else if(pltot>dltot){
                                cout<<"You won ! "<<endl<<endl;
                            }
                        }   
                    }   
                }
            
            
            } 
    //Display output
            
    
    //Exit stage right
            input.close();
            
            cout<<"Play again? (y/n)"<<endl<<endl;
            cin>>again;
            
             }
            
    return 0;
}
void pullcrd(const int nCards,int& plcd1,int& plcd2,int& plcd3,int& plcd4,int& plcd5,int& dlcd1,int& dlcd2,int& dlcd3,int& dlcd4,int& dlcd5,int& dltot){
         srand(static_cast<unsigned int>(time(0)));
            plcd1=rand()%nCards+1;                                                                 //Pull player card 1
             
            do{                                                                                   //Pull player card 2
                plcd2=rand()%nCards+1;
            }while(plcd1==plcd2);                                                                
            if(plcd1>plcd2){                                                                       //Sort card in order
                unsigned short temp=plcd1;
                plcd1=plcd2;
                plcd2=temp;
                
            }
            
            do{                                                                                     //Pull dealer card 1
                dlcd1=rand()%nCards+1;
            }while(dlcd1==plcd1 || dlcd1==plcd2); 
            
            do{                                                                                     //Pull dealer card 2
                dlcd2=rand()%nCards+1;
            }while(dlcd2==dlcd1 || dlcd2==plcd1 || dlcd2==plcd2);
            
            if(dlcd1>dlcd2){                                                                           //Sort dealer's card in order
                unsigned short temp=dlcd1;
                dlcd1=dlcd2;
                dlcd2=temp;
            }
            
            do{
                plcd3=rand()%nCards+1;
            }while(plcd3==plcd1 || plcd3==plcd2 || plcd3==dlcd1 || plcd3==dlcd2);                      //Pull player card 3 if player hits
            
                dltot=dlcd1+dlcd2;                                                                  //Calculate dealer's total
            
            
            do{
                    dlcd3=rand()%nCards+1;
            }while(dlcd3==dlcd1||dlcd3==dlcd2||dlcd3==plcd1||dlcd3==plcd2||dlcd3==plcd3);     //Pull dealer card 3 
            
            do{
                plcd4=rand()%nCards+1;
            }while(plcd4==plcd1||plcd4==plcd2||plcd4==dlcd1||plcd4==dlcd2||plcd4==plcd3||plcd4==dlcd3);             //Pull player card 4
            
            do{
                dlcd4=rand()%nCards+1;
            }while(dlcd4==plcd1||dlcd4==plcd2||dlcd4==dlcd1||dlcd4==dlcd2||dlcd4==plcd3||dlcd4==dlcd3||dlcd4==plcd4);    //Pull dealer card 4
            
            do{
                plcd5=rand()%nCards+1;
            }while(plcd5==plcd1||plcd5==plcd2||plcd5==dlcd1||plcd5==dlcd2||plcd5==plcd3||plcd5==dlcd3||plcd5==plcd4||plcd5==dlcd4);   //Pull player card 5
            
            do{
                dlcd5=rand()%nCards+1;
            }while(dlcd5==plcd1||plcd5==plcd2||plcd5==dlcd1||plcd5==dlcd2||dlcd5==plcd3||dlcd5==dlcd3||dlcd5==plcd4||dlcd5==dlcd4||dlcd5==plcd5); //Pull dealer card 5
             
}

